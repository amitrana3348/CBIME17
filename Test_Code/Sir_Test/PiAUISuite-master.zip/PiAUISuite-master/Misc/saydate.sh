#!/bin/bash

current=`date`
echo "$current"
tts "FILLER FILL $current"
